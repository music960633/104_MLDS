#! /usr/bin/python

import train

def main():
  train.run()

if __name__ == "__main__":
  main()
